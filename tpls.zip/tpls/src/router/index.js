import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import VueResource from 'vue-resource'

import home from '@/components/home'
import more from '@/components/more'
import detail from '@/components/detail'
import imgs from '@/components/imgs'
import cang from '@/components/cang'
Vue.use(Router)
Vue.use(VueResource)
export default new Router({
  routes: [
    {
      path: '/',
      component: home
    },
    {
      path:'/more',
      component:more
    },
    {
      path:'/detail',
      component:detail
    },
    {
      path:'/imgs',
      component:imgs
    },
    {
      path:'/cang',
      component:cang
    }
  ]
})
