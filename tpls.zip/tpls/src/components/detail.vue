<template>
    <div class="detail">
        <mt-search style="height:80px;"></mt-search>
        <div class="bannerdiv">
            <mt-swipe :auto="4000" class="banner" >
                <mt-swipe-item>
                    <img src="../assets/img/more1.jpg" alt="">
                </mt-swipe-item>
                <mt-swipe-item>
                    <img src="../assets/img/more2.jpg" alt="">
                </mt-swipe-item>
                <mt-swipe-item>
                    <img src="../assets/img/more3.jpg" alt="">
                </mt-swipe-item>
                <mt-swipe-item>
                    <img src="../assets/img/more4.jpg" alt="">
                </mt-swipe-item>
            </mt-swipe>
            <ul>
                <li> <b>新闻介绍</b> <br>
                <span>子介绍子介绍子介绍子介绍</span></li>
                <li><b>新闻介绍</b><br>
                <span>子介绍子介绍子介绍子介绍</span></li>
                <li><b>新闻介绍</b><br>
                <span>子介绍子介绍子介绍子介绍</span></li>
                <li><b>新闻介绍</b><br>
                <span>子介绍子介绍子介绍子介绍</span></li>
            </ul>
        </div>
        <div class="main">
            <ul class="out">
                <li> <span class="title"> <i>焦点新闻</i> </span> 
                <br>  FOCAL NEWS <br><br>
                <ul>
                    <li><span class="title"> <i>XXXXXXXXXXXXX</i> </span> 
                    <br> xxxxxxx <br></li>
                    <li><span class="title"> <i>XXXXXXXXXXXXXX</i> </span> 
                    <br> xxxxxxx <br></li>
                    <li><span class="title"> <i>XXXXXXXXXXXXXX</i> </span> 
                    <br> xxxxxxx <br></li>
                    <li><span class="title"> <i>XXXXXXXXXXXXXX</i> </span> 
                    <br> xxxxxxx <br></li>
                    <li><span class="title"> <i>XXXXXXXXXXXXXX</i> </span> 
                    <br> xxxxxxx <br></li>
                    <li><span class="title"> <i>XXXXXXXXXXXXXX</i> </span> 
                    <br> xxxxxxx <br></li>
                    <li><span class="title"> <i>XXXXXXXXXXXXXX</i> </span> 
                    <br> xxxxxxx <br></li>
                    <li><span class="title"> <i>XXXXXXXXXXXXXX</i> </span> 
                    <br> xxxxxxx <br></li>
                    
                </ul>
                </li>
                <li> <span class="title"> <i>视频新闻</i> </span>
                    <br>
                    VIDEO NEWS
                    <ul class="video">
                        <li>
                            <video src="../assets/mp4/news.mp4" controls="controls"></video>
                            <b>abcabcabcabcabc</b>    
                        </li>
                        <li><video src="../assets/mp4/news.mp4" controls="controls"></video>
                            <b>abcabcabcabcabc</b>  
                        </li>
                        <li><video src="../assets/mp4/news.mp4" controls="controls"></video>
                            <b>abcabcabcabcabc</b>  
                        </li>
                    </ul>
                </li>
            </ul>
            <ul class="out"
                v-infinite-scroll="loadMore"
                infinite-scroll-disabled="loading"
                infinite-scroll-distance="0"
            >
                <li> <span class="title"> <i>时政要闻</i> </span> 
                <br>  FOCAL NEWS <br><br>
                <ul>
                    <li  v-for="item in list"><span class="title"> <i>{{item.title}}</i> </span> 
                    <br>{{item.subtitle}}<br></li>
                    
                    
                </ul>
                </li>
                <li> <span class="title"> <i>热门新闻</i> </span>
                    <br>
                    VIDEO NEWS
                   <ul>
                    <li  v-for="item in list"><span class="title"> <i>{{item.title}}</i> </span> 
                    <br>{{item.subtitle}}<br></li>
                    
                    
                   </ul>
                </li>
            </ul>
        </div>
         
    </div>
</template>
<script>
    export default {
         data:function(){
           return {
               loading:false,
               list:[
                   {
                   title:'abcabcabcabcabcabcabcabc',
                   subtitle:'xxxxxxxxxxxxxxxxxxxxxxx'
                   }
               ]
            }  
        },
        methods:{
            loadMore(){
              this.loading = true;
              this.$indicator.open({
                text: '加载中...',
                spinnerType: 'double-bounce'
                });
                setTimeout(() => {
                    let last = this.list[0];
                    for (let i = 1; i <=3; i++) {
                    this.list.push(last);
                    }
                    this.loading = false;
                    console.log(this.loading)
                    this.$indicator.close();
                }, 1500);
             }
        }
    }    
</script>
<style>
    .detail ul{
        list-style: none;
        padding:0;
    }
    .main li{
        padding:10px 0;
    }
    .detail .mint-header{
        height:55px;
        font-size: 30px;
        line-height: 55px;
    }
    .detail .mint-header .mint-button{
        line-height: 32px;
    }
    .detail .bannerdiv{
       text-align:left;
       position: relative;
    }
    .detail .banner{
        height:300px;
        overflow: hidden;
        width:60%; 
        display: inline-block;
    }
   .detail .banner img{
        width:100%;
        height:100%;
        /* vertical-align: top; */
    }
    .detail ul{
        list-style: none;
        display: inline-block;
        padding-left: 5px;
    }
    .bannerdiv ul li{
        font-size: 28px;
    }
    .bannerdiv ul li span {
        font-size: 20px;
        font-family: simhei;
    }
    .main ul.out{
        text-align: left;
        width:100%;
    }
    .main ul.out>li{
        border-top:2px solid #ccc;
        text-align: left;
        list-style: none;
        padding:0;
        float: left;
        box-sizing: border-box;
        /* width:48%; */
        font-size: 25px;
        margin:0 1%;
    }
    .main ul.out>li:first-child{
        width:64%;
        border-top:2px solid #4A7FB5;
    }
    .main ul.out>li:last-child{
        width:32%;
        overflow: hidden;
    }
    .main ul.out>li .title{
        font-size: 32px;
        font-weight: bold;
    }
    .video{
        width:100%;
    }
    .video video{
        width:80%;
        height:150px;
    }
     .video b{
        width:100%;
    }
</style>
