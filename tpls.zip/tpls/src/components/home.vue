<template>
    <div class="home">
        <mt-search style="height:80px;"></mt-search>
        <mt-swipe :auto="4000" class="banner" >
            <mt-swipe-item>
                <img src="../assets/img/img1.jpg" alt="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../assets/img/img2.jpg" alt="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../assets/img/img3.jpg" alt="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../assets/img/img4.jpg" alt="">
            </mt-swipe-item>
        </mt-swipe>
       <div class="homenew">
        <h1>下滑加载更多</h1>
            <div @click.prevent="jumplook" >
            <mt-cell
                 
                label="春节到来,全过各地迎来人流量新高,春节到来,全过各地迎来人流量新高..." >
                <img slot="icon" src="../assets/img/gao.jpg" >
                <span>更多精彩</span>
            </mt-cell>
            </div>
            <div  @click.prevent="jumplook" >
            <mt-cell
                label="春节到来,全过各地迎来人流量新高,春节到来,全过各地迎来人流量新高..." >
                <img slot="icon" src="../assets/img/gao.jpg" >
                 <span @click="jumplook">更多精彩</span>
            </mt-cell>
            </div>
            <ul
                v-infinite-scroll="loadMore"
                infinite-scroll-disabled="loading"
                infinite-scroll-distance="0">
                 
                <li v-for="item in list">
                    <div class="left">
                         <span class="title">
                       {{ item.title }}
                         </span><br>

                        <span class="subtitle">
                            {{item.subtitle}}
                        </span>
                    </div>
                    <div class="right">
                        <img :src="require('../assets/'+item.img)" alt="">
                    </div>
                    
                </li>
            </ul>
            

            
       </div>
       
    </div>
</template>
<script>
    export default {
        
       data:function(){
           return {
               loading:false,
               list:[
                   {
                   title:'今天空气重度污染 明天午后空气改善',
                   subtitle:'昨日是北京市启动空气重污染橙色预警第二天，全市各区和有关单位继续严格落实各项应急措施，加强执法监督',
                   img:"img/load.jpg"
                   }
               ]
            }  
        },
        methods:{
            loadMore(){
              this.loading = true;
              this.$indicator.open({
                text: '加载中...',
                spinnerType: 'double-bounce'
                });
                setTimeout(() => {
                    let last = this.list[0];
                    for (let i = 1; i <=3; i++) {
                    this.list.push(last);
                    }
                    this.loading = false;
                    console.log(this.loading)
                    this.$indicator.close();
                }, 1500);
             },
             jumplook(){
                 this.$emit('jump','更多')
                 this.$router.push('/detail')
             }
        }
    }
</script>
<style>
   .home .banner{
        height:400px;
        overflow: hidden;
        width:100%; 
        margin-bottom: 10px;
    }

   .home .banner img{
        width:100%;
        height:100%;
    }
   .home .mint-cell{
        text-align:left;
        padding:10px;
    }
   .home .mint-cell span{
        font-size: 30px;
        font-family: simhei;
    }
   .home .mint-cell img{
        width:300px;
        height:200px;
    }
   .home ul{
        list-style: none;
        text-align: left;
    }
   .home ul li {
       height:120px;
    }
  .home  ul img {
        height:80%;        
    }
  .home ul li .title{
      font-size: 30px;
      line-height: 50px;
  }

  .home ul li .subtitle{
      font-size: 20px;
      font-family: simhei;
      padding:0 10px;
      margin: 10px 0;
      width:100%;
  }
  .home ul li .left{
      display: inline-block;
      width:75%;
  }
  .home ul li .right{
        display: inline-block;
      height:100%;
      width:20%;
  }
    
</style>

