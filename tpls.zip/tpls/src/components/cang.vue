<template>
    <div class="cang">
        <div class="bannerdiv">
            <mt-swipe :auto="4000" class="banner" >
                <mt-swipe-item>
                    <img src="../assets/img/cang1.jpg" alt="">
                </mt-swipe-item>
                <mt-swipe-item>
                    <img src="../assets/img/cang2.jpg" alt="">
                </mt-swipe-item>
                <mt-swipe-item>
                    <img src="../assets/img/cang3.jpg" alt="">
                </mt-swipe-item>
                <mt-swipe-item>
                    <img src="../assets/img/cang4.jpg" alt="">
                </mt-swipe-item>
            </mt-swipe>
           <div class="login" v-if="islogin">
               <h1>登录更 <i style="color:#2F91B7;font-size:40px;">懂你</i></h1>
 
               <mt-field :state="loginState"   placeholder="请输入用户名////无" v-model="username" ></mt-field>
               <mt-field :state="loginState"   placeholder="请输入密码////无" type="password" v-model="password"></mt-field>
               <mt-button type="primary" size="large" @click="login">登录</mt-button>
           </div>
           <div class="logined" v-if="!islogin">
               <ul>
                   <li class="avatar">
                       <img src="../assets/img/avatar.jpg" alt="">
                   </li>
                   <li>
                       <mt-radio 
                            :options='options'>
                        </mt-radio>
                   </li>
                   <li class="msg">
                       <h3>您有未读的消息</h3>
                       <mt-badge type="error" class="num">23</mt-badge>
                   </li>
                   <li class="msg">
                       <h3>您有新的收藏更新</h3>
                       <mt-badge type="success" class="num">3</mt-badge>
                   </li>
               </ul>
           </div>
        </div>
        <div class="main">
            <ul>
                <li class="left">
                    <ul class="left_ul" style="text-align:left">
                        <li>
                            <img src="../assets/img/cangmain1.jpg" alt="" class="news"> 
                            <div style="display:inline-block">
                                <h1>今日:xxxxxxxxx</h1>
                            <h3>原标题:今日xxxxxxxxxxxxxxx</h3>
                            </div>
                        </li>
                        <li>
                            <img src="../assets/img/cangmain1.jpg" alt="" class="news"> 
                            <div style="display:inline-block">
                                <h1>今日:xxxxxxxxx</h1>
                            <h3>原标题:今日xxxxxxxxxxxxxxx</h3>
                            </div>
                        </li>
                        <li>
                            <img src="../assets/img/cangmain1.jpg" alt="" class="news"> 
                            <div style="display:inline-block">
                                <h1>今日:xxxxxxxxx</h1>
                            <h3>原标题:今日xxxxxxxxxxxxxxx</h3>
                            </div>
                        </li>
                        <li>
                            <img src="../assets/img/cangmain1.jpg" alt="" class="news"> 
                            <div style="display:inline-block">
                                <h1>今日:xxxxxxxxx</h1>
                            <h3>原标题:今日xxxxxxxxxxxxxxx</h3>
                            </div>
                        </li>
                        <li>
                            <img src="../assets/img/cangmain1.jpg" alt="" class="news"> 
                            <div style="display:inline-block">
                                <h1>今日:xxxxxxxxx</h1>
                            <h3>原标题:今日xxxxxxxxxxxxxxx</h3>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="right">
                    <h1>热门新闻排行榜</h1>
                    <h2>1.xxxxxxxxxxxxxx</h2>
                    <h2>2.xxxxxxxxxxxxxx</h2>
                    <h2>3.xxxxxxxxxxxxxx</h2>
                    <h2>4.xxxxxxxxxxxxxx</h2>
                    <h2>5.xxxxxxxxxxxxxx</h2>
                    <h2>6.xxxxxxxxxxxxxx</h2>
                    <h2>7.xxxxxxxxxxxxxx</h2>
                    <h2>8.xxxxxxxxxxxxxx</h2>
                    <h2>9.xxxxxxxxxxxxxx</h2>
                    <h2>10.xxxxxxxxxxxxxx</h2>
                    <h2>11.xxxxxxxxxxxxxx</h2>

                </li>
            </ul>
        </div>
    </div>
</template>
<script>
    export default {
        data:function(){
            return{
                username:'',
                password:'',
                loginState:'',
                islogin:true,
                options:[
                    {
                        label: '记住密码',
                        value: '值F',
                        disabled: false
                    }
                ]
            }
        },
        methods:{
            login(){
                this.islogin=false
            }
        }
    }
</script>
<style>
    .cang ul{
        list-style: none;
        padding:0;
    }
    .cang h1,.cang h3{
        margin:0;
    }
    .cang .bannerdiv{
       text-align:left;
       position: relative;
    }
    .cang .banner{
        height:300px;
        overflow: hidden;
        width:50%; 
        display: inline-block;
    }
   .cang .banner img{
        width:100%;
        height:100%;
        /* vertical-align: top; */
    }
    .cang .login {
        display: inline-block;
        width:48%;
        box-sizing: border-box;
        position: absolute;
        top:0;
        right:0;
    }
    .cang .logined {
        display: inline-block;
        width:48%;
        box-sizing: border-box;
        position: absolute;
        top:0;
        right:0;
    }
    .login .mint-cell{
        height:100px;
    }
   .login .mint-cell-text{
       font-size: 30px;
   }
   .login .mint-cell-value{
       font-size: 30px;
   }
   .logined ul .avatar{
       height:100px;
       text-align: center; 
   }
   .logined ul .avatar img{
       width:25%;
       height:100%;
   }
   .logined .msg{
       margin:10px 0;
       line-height: 25px;
       clear: both;
       padding:10px 0;
   }
   .logined .msg h3{
       float: left;
       margin:0
   }
   .logined .msg .num{
       float: right;
       width:40px;
       font-size: 20px;
   }
   .cang .main>ul{
       clear: both;
   }
   .cang .main .left,.cang .main .right{
       float: left;
       border-top:2px solid #ccc;
       padding: 10px 0 ;
   }
   .cang .main .left{
       width:70%;

   }
   .cang .main .right{
       width:30%;
   }
   .cang .news{
       width:40%;
       height: 150px;
       vertical-align: top;
   }
   .mint-radio-label{
       font-size: 25px;
   }
   .left_ul li {
       padding:10px 0;
   }
   
</style>

<style lang="stylus" type="text/stylus" rel="stylesheet/stylus" scoped> 
    .home2,.heart,.images,.more{
        display inline-block
        width:1.5rem
        height:1.5rem
        font-size:1.5rem
        color:#fff
    }
</style>
