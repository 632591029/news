<template>
  
  <div class="imgs">
      <mt-header fixed title="固定在顶部" style="height:60px;"></mt-header>
              <h1> <i>下滑加载  图片懒加载</i> </h1>
      <!-- <ul>
            <li v-for="item in list">
                <img v-lazy="require('../assets/'+item.img)"  lazy="loading">
                <div class="word">
                    <span class="title">{{item.title}}</span>
                    <span>{{item.subtitle}}</span>
                </div>
                
            </li>
      </ul> -->
      <ul
                v-infinite-scroll="loadMore"
                infinite-scroll-disabled="loading"
                infinite-scroll-distance="0">
                <li v-for="item in list">
                    <img v-lazy="require('../assets/'+item.img)"  lazy="loading">
                    <div class="word">
                        <span class="title">{{item.title}}</span>
                        <span>{{item.subtitle}}</span>
                    </div>
                </li>
      </ul>
      
  </div>
</template>
<script>
    export default {
         data:function(){
           return {
               loading:false,
               n:0,
               list:[
                   {img:'img/imgs1.jpg',
                    title:'李娜退役赛事突然遇冷 中国网球还能消费谁',
                    subtitle:'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'                   
                   },
                   {img:'img/imgs2.jpg',
                    title:'银行业不良率连续四季度持平',
                    subtitle:'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'                       
                   },
                   {img:'img/imgs3.jpg',
                    title:'临阵换帅仍斩排超首胜 八一女排3-0轻取河南',
                    subtitle:'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'                       
                   },
                   {img:'img/imgs4.jpg',
                    title:'第27届中国厨师节厨师唱响“工匠精神',
                    subtitle:'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'    
                   }
               ]
            }  
        },
        methods:{
            loadMore(){
              this.loading = true;
              this.$indicator.open({
                text: '加载中...',
                spinnerType: 'double-bounce'
                });
                setTimeout(() => {
                    if(this.n>3){
                        this.n=0;
                    }
                    let last = this.list[this.n];
                    this.list.push(last);   
                    this.$indicator.close();
                    this.n+=1
                }, 1500);
                this.loading=false
             }
        }
    }    
</script>
<style>
        body{
            margin: 0;
        }
      .imgs{
          background: #ccc;
      }
      .imgs ul{
          list-style: none;
          padding:0;
      }
      .imgs ul li{
          padding:0;
          text-align: left;
      }
      .imgs ul li img{
          width:100%;
          height:400px;
      }
      .imgs  img[lazy=loading] {
        width: 100%;
        height: 300px;
        margin: auto;
        background: #ccc;
        }
      .imgs ul li .title{
          font-size: 28px;
          color:#2d2d2d;
          font-weight: bold;
          display: block;
      }
      .imgs ul li .word span:last-child{
          color:#2F91B7;
      }
      .imgs ul li .word{
          margin:10px 0;
          margin-bottom: 50px;
      }
</style>

