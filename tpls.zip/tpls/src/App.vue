<template>
  <div id="app">
    <router-view @jump="rvcmsg" ></router-view>
    <mt-tabbar class="foot" v-model="selected" style="position:fixed;">
        <mt-tab-item id="首页">
            
           <router-link to="/">
        <i class="icon-home2"></i> <br>
           <span class="foot_word">首页</span></router-link> 
        </mt-tab-item>
        <mt-tab-item  id="更多">
           <router-link to="/detail"><i class="icon-more"></i> <br>  <span class="foot_word">更多</span></router-link> 
        </mt-tab-item>
        <mt-tab-item  id="图库">
           <router-link to="/imgs"><i class="icon-images"></i><br><span class="foot_word">&nbsp;图库</span></router-link> 
        </mt-tab-item>
        <mt-tab-item  id="收藏">
           <router-link to="/cang"><i class="icon-heart"></i><br><span class="foot_word">收藏</span></router-link> 
        </mt-tab-item>
        </mt-tabbar>
  </div>
</template>

<script>
export default {
  name: 'app',
  data:function(){
      return{
          selected:'首页'
      }
  },
  methods:{
      rvcmsg(msg){
          this.selected=msg;
          console.log(this.selected)
      }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.foot{
    position:fixed;
   box-shadow: 0 0 5px 5px #ccc;
   /* background: #2F91B7;       */
       height:100px; 
}
.mint-tab-item-label{
    font-size: 30px;
    margin-top: 10px;
}
a.mint-tab-item{
   /* background-color: #2F91B7;     */
}
.mint-tab-item-label{
    color:#fff;
    font-family: simhei;
}
.foot .is-selected{
    background: #ccc;

}
.foot .is-selected a{
    color:grey;
    
}
.foot  a{
    text-decoration: none;  
    color:#2d2d2d;
}
.icon-heart,.icon-home2,.icon-images,.icon-more{
        display :inline-block;
        width:2.5rem;
        height:2.5rem;
        font-size:3rem;
        color:#848484;
}
.foot .foot_word{
    font-size:25px;
}

</style>

<style lang="stylus" type="text/stylus" rel="stylesheet/stylus"> 
    @import "./common/stylus/icon.styl";

</style>

